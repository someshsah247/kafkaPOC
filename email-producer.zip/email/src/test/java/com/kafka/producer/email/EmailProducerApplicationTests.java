package com.kafka.producer.email;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailProducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
